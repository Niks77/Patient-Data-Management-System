from django.contrib import admin
from patient_management import models
from django.contrib.auth.admin import UserAdmin
# Register your models here.

class UsersAdmin(UserAdmin):
    list_display = ('email','username','last_login','is_admin', 'is_staff','is_superuser',
    'banned' , 'approved', 'password')
    search_fields = ('email', 'username')
    # readonly_fields = ('last_login')

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'password', 'is_admin'),
        }),
    )
    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()
class OrgAdmin(UserAdmin):
    list_display = ('name','description','location','contactDetails', 'banned','approved',
    'type')
    search_fields = ('email', 'username')
    # readonly_fields = ('last_login')

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('name','description','location','contactDetails', 'banned','approved',
    'type'),
        }),
    )
    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()
admin.site.register(models.User,UsersAdmin)
admin.site.register((models.Organization))