
import re
from fcs_project import settings
from  gmpy2 import mpz
from django.shortcuts import HttpResponse, redirect, render
from patient_management.models import Organization, User , PDocument, HCPDocument , File
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import check_password
from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import EmailMessage, send_mail
from patient_management.certificate import (verify, generate_key) 
from . tokens import generate_token
# Create your views here.

@login_required(login_url='signin')
def home(request):
    
    return render(request,"patient_management/index.html")

def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        fname = request.POST.get('fname')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password1 = request.POST.get('password1')
        type = request.POST.get('type')

        try:
            license = request.FILES['license']
        except:
            license = None
     
        try:
            identity = request.FILES['identity']
        except:
            identity =  None
        emailRegex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        if User.objects.filter(username=username):
            messages.error(request, "Username already exist! Please try some other username.")
            return redirect('signup')
        if type == None:
            messages.error(request, "Please select user type")
            return redirect('signup')
        if type != "Patient" and type != "Healthcare Professional":
            messages.error(request, "Please select valid user type")
            return redirect('signup')
        if not re.fullmatch(emailRegex,email):
            messages.error(request, "Enter valid email")
            return redirect('signup')
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email Already Registered!!")
            return redirect('signup')
        if identity == None:
            messages.error(request,"Identity document is compulsory")
            return redirect('signup')
        if type == "Healthcare Professional" and license == None:
            messages.error(request,"License document is compulsory")
            return redirect('signup')
        if password != password1:
            messages.error(request, "Passwords didn't matched!!")
            return redirect('signup')

        if not username.isalnum():
            messages.error(request, "Username must be Alpha-Numeric!!")
            return redirect('signup ')
        myuser = User.objects.create_user(username,fname,email,password,type)
        if(type == "Patient"):
            try:
                doc = PDocument(user = myuser,identity_proof = identity)
                doc.save()
            except:
                myuser.delete()
                messages.error(request, "Unknown error occured")
                return redirect('signup')
        elif(type == "Healthcare Professional"):
            try:
                doc = HCPDocument(user = myuser,identity_proof = identity, license_proof= license)
                doc.save()
            except:
                myuser.delete()
                messages.error(request, "Unknown error occured")
                return redirect('signup')
        messages.success(request, "Your Account has been created succesfully!! Please check your email to confirm your email address in order to activate your account.")
        current_site = get_current_site(request)
        email_subject = "Confirm your Email @ GFG - Django Login!!"
        message2 = render_to_string('patient_management.email_confirmation.html',{
            
            'name': myuser.name,
            'domain': current_site.domain,
            'username':(myuser.username),
            'token': generate_token.make_token(myuser)
        })
        email = EmailMessage(
        email_subject,
        message2,
        settings.EMAIL_HOST_USER,
        [myuser.email],
        )
        email.fail_silently = True
        email.send()
        
        return redirect('signin')
    

    return render(request,"patient_management/signup.html")
@login_required(login_url='signin')
def editProfile(request):
    if request.method == "POST":
        user = request.user
        if user == None:
            messages.error(request, "Session expired")
            return redirect('signin')
       
        fname = request.POST.get('fname')
        user.name = fname
        messages.success(request, "Your account name has been changed successfully")
        return redirect('home')

    return render(request,"patient_management/signup.html")

@login_required(login_url='signin')
def search(request):
    
    query = request.POST.get("q",None)
    if query is not None:
        user = User.objects.filter(
            name__contains=query) 
        org = Organization.objects.filter(
            name__contains = query
        )
        return render(request,"patient_management/index.html", {"data":{"users":user,"org":org}})
    

def activate(request,username,token):
    try:
        myuser = User.objects.get(username = username)
    except (TypeError,ValueError,OverflowError,User.DoesNotExist):
        myuser = None

    if myuser is not None and generate_token.check_token(myuser,token):
        myuser.is_active = True
        # user.profile.signup_confirmation = True
        myuser.save()
        login(request,myuser)
        messages.success(request, "Your Account has been activated!!")
        return redirect('signin')
    else:
        return render(request,'activation_failed.html')
def load_dropdown(request):
     type = request.GET.get('type')
     return render(request, 'patient_management/fileupload.html', {'type': type})

@login_required(login_url='signin')
def verify(request, pk) :
    print(request)
    if request.method == "POST":
        if request.user == None:
            messages.error(request, "Session expired")
            return redirect('signin')
        else:  
            user = request.user
            if user == None:
                messages.error(request, "Session expired")
                return redirect('signin')
            else:
                try:
                    file = File.objects.get(pk=pk)
                except:
                    file = None
                if file is None:
                    messages.error(request,"File is missing or wrong request")
                    return redirect('/')
                else:
                    if verify(file.cipher,user.username,file.file_path):
                        messages.success(request, "File is verified")
                        return redirect('/')

                    else :
                        messages.error(request, "File is not verified")
   
                        return redirect('/')

@login_required(login_url='signin')
def delete(request, pk) :
    if request.method == "GET":
        if request.user == None:
            messages.error(request, "Session expired")
            return redirect('signin')
        else:  
            user = request.user
            if user == None:
                messages.error(request, "Session expired")
                return redirect('signin')
            else:
                try:
                    file = File.objects.get(pk=pk)
                except:
                    file = None
                if file is None:
                    messages.error(request,"File is missing or wrong request")
                    return redirect('your_docs')
                else:
                    if file.user == user:
                        file.delete()
                        messages.success(request,"File is deleted")
                        return redirect('your_docs')
                    messages.error(request,"you are not owner of the files cannot delete that !!")
                    return redirect('your_docs')

                    

@login_required(login_url='signin')
def upload_files(request):
    if request.method == "POST":
        if request.user == None:
            messages.error(request, "Session expired")
            return redirect('signin')
        else:  
            user = request.user

            if user == None:
                messages.error(request, "Session expired")
                return redirect('signin')
            else:
                title = request.POST.get('title')
                description = request.POST.get('description')
                try:
                    file_path = request.FILES['docs']
                except:
                    file_path = None
                other_user_as_owner = request.POST.get('share_owner')
                share_username = request.POST.get('share_username')
                try:
                    share_user = User.objects.get(username = share_username)
                except:
                    share_user = None
                print(share_user)
                if share_user is None:
                    messages.error(request,"User doesnt exists")
                    return redirect('upload')
                if share_username == user.username:
                    messages.error(request,"You cannot share with yourself")
                    return redirect('upload')
                if title is None:
                    messages.error(request,"title is required")
                    return redirect('upload')
                if description is None:
                    messages.error(request,"description is required")
                    return redirect('upload')
                if file_path is None:
                    messages.error(request,"file is needed to be upload")
                    return redirect('upload')
                if share_user.banned:
                    messages.error(request,"share user is banned")
                    return redirect('upload')
                if not share_user.approved:
                    messages.error(request,"share user is not approved to use platform")
                    return redirect('upload')
                fileObj = File(user=user,title=title,description=description,file_path=file_path)
                fileObj.save()
                fileObj.share.add(share_user)
                fileObj.save()
                messages.success(request,"files has successfully shared with user:" + str(share_user.username))
                return redirect('upload')
    return  render(request,"patient_management/uploadfile.html")         

@login_required(login_url='signin')
def your_docs(request):
    if request.method == "GET":
        if request.user == None:
            messages.error(request, "Session expired")
            return redirect('signin')
        else: 
            user = request.user
            if user == None:
                messages.error(request, "Session expired")
                return redirect('signin')
            else:
                files = user.file_set.all()
                return render(request,"patient_management/owndocs.html",{'files': files})
    
@login_required(login_url='signin')
def shared_docs(request):
    if request.method == "GET":
        if request.user == None:
            messages.error(request, "Session expired")
            return redirect('signin')
        else: 
            user = request.user
            if user == None:
                messages.error(request, "Session expired")
                return redirect('signin')
            else:
                files = File.objects.filter(share=user)
                return render(request,"patient_management/shareddocs.html",{'files': files})

@login_required(login_url='signin')
def change_password(request):
    if request.method == "POST":
        if request.user == None:
            messages.error(request, "Session expired")
            return redirect('signin')
        else: 
            user = request.user
            if user == None:
                messages.error(request, "Session expired")
                return redirect('signin')
            else:
                old_password = request.POST.get('oldpassword')
                new_password = request.POST.get('newpassword')
                confirm_password = request.POST.get('confirmpassword')
                if not check_password(old_password,user.password):
                    messages.error(request, "You are entering wrong password")
                    return redirect('changepassword')
                elif new_password != confirm_password:
                    messages.error(request, "New password and confirm password are not same")
                    return redirect('changepassword')
                else:
                    user.set_password(new_password)
                    user.save()
                    messages.success(request, "Password has been successfully changed")
                    return redirect('/')

    return render(request,"patient_management/changepassword.html")  

def signin(request):
    if request.method == "POST":
        password = request.POST.get('password')
        username = request.POST.get('username')
        # print(password + " "+ email)
        user = authenticate(username=username, password = password)
        # print(user)
        if user is None:
            messages.error(request, "Wrong username / password")
            return redirect('signin')
        if user.banned :
            messages.error(request, "Your account is suspended")
            return redirect('signin')
        if not user.approved:
            messages.error(request, "Your account is not been approved yet wait for admin's approval")
            return redirect('signin')
        if not user.is_active:
            messages.error(request, "Verify your email address first")
            return redirect('signin')
         
        login(request, user)
        return redirect('home')
        
    return render(request,"patient_management/Login.html")

@login_required(login_url='signin')
def signout(request):
    logout(request)
    return redirect('signin')