from decouple import config
import hashlib
e = config('E')
n = config('N')
d = config('D')



def decrypt(hash):
    s = []
    for i in hash.encode():
        s.append(gmpy2.powmod(i, e, n))
    return s

def encrypt(hash):
  
    s = ''
    for i in hash.encode():
        s += chr(gmpy2.powmod(i, d, n))
    
    return s

def verify(cipher, username,file_path):
    hash = decrypt(cipher)
    sha256_hash = hashlib.sha256()
    try:
        with open(file_path,"rb") as f:
    # Read and update hash string value in blocks of 4K
            for byte_block in iter(lambda: f.read(4096),b""):
                sha256_hash.update(byte_block)
            new_hash = sha256_hash.hexdigest()
            return username + new_hash == hash
    except:
        return False
    

def generate_key(username,file_path):
    sha256_hash = hashlib.sha256()
    try:
        with open(file_path,"rb") as f:
        # Read and update hash string value in blocks of 4K
            for byte_block in iter(lambda: f.read(4096),b""):
                sha256_hash.update(byte_block)
            new_hash = sha256_hash.hexdigest()
            return encrypt(username + str(new_hash))
    except:
        pass

        
